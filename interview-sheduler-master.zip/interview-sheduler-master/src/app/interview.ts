export class Interview {
    id?: number;
    name?: string;
    emailId?: string;
    phNumber?: string;
    skills?: string;
    experience?: number;
    date?: string;
    time?: string;
    link?: string;
    poc?: string;
  }