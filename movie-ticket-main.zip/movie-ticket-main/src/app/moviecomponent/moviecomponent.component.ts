import { Component } from '@angular/core';

@Component({
  selector: 'app-moviecomponent',
  templateUrl: './moviecomponent.component.html',
  styleUrls: ['./moviecomponent.component.css']
})
export class MoviecomponentComponent {

}
